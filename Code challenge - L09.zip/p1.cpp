#include <iostream>
using namespace std;

// Part 1
template <typename T>
T max2Value(T a, T b) {
    return (a > b) ? a : b;
}

template <typename T>
T max3Value(T a, T b, T c) {
    return max2Value(a, max2Value(b, c));
}

int main() {
    cout << "PART 1.1" << endl;
    cout << max2Value(7, 24) << endl;    
    cout << max2Value(5.6, 8.1) << endl;   
    cout << max2Value(string("Jose"), string("Camila")) << endl; 

    cout << "" << endl;

    cout << "PART 1.2" << endl;
    cout << max3Value(0, 2, 8) << endl;       
    cout << max3Value(3.8, 12.4, 0.6) << endl; 
}