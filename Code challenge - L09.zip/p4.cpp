#include <iostream>

//PART 4

template <int N>
struct Factorial {
    static constexpr int value = N * Factorial<N - 1>::value;
};

template <>
struct Factorial<0> {
    static constexpr int value = 1;
};

///////////////
template <int N>
struct Fibonacci {
    static constexpr int value = Fibonacci<N - 1>::value + Fibonacci<N - 2>::value;
};
//required values
template <>
struct Fibonacci<0> {
    static constexpr int value = 0;
};

template <>
struct Fibonacci<1> {
    static constexpr int value = 1;
};


int main() {
    std::cout << "Part 4.1" << std::endl;
    constexpr int result_1 = Factorial<3>::value;
    constexpr int result_2 = Factorial<0>::value;
    std::cout << result_1 << std::endl;
    std::cout << result_2 << std::endl;
    std::cout << " " << std::endl;

    std::cout << "Part 4.2" << std::endl;
    constexpr int result_3 = Fibonacci<14>::value;
    std::cout << result_3 << std::endl; // Should print 55
}
