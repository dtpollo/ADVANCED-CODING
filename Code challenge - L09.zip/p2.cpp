#include <iostream>
#include <concepts>

//PART 2

template <typename T>
concept Numeric = std::integral<T> || std::floating_point<T>;

template <Numeric T>
T add(T a, T b) {
    return a + b;
}


int main() {
    std::cout << add(9, 1) << std::endl;       
    std::cout << add(2.5, 2.5) << std::endl;   
    return 0; 
}