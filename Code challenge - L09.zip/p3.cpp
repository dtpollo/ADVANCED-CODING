#include <iostream>
//PART 3

template <typename T>
void printAll(T t) {
    std::cout << t << std::endl;
}

template <typename T, typename... Args>
void printAll(T t, Args... args) {
    std::cout << t << "     ";
    printAll(args...);
}

///////

template <typename T>
T sum(T t) {
    return t;
}

template <typename T, typename... Args>
T sum(T t, Args... args) {
    return t + sum(args...);
}

int main() {
    std::cout << "Part 3.1" << std::endl;
    printAll(5.6, 3, "Damn", 'i', 3, "HELLOOOU"); 
    std::cout << "" << std::endl;
    std::cout << "Part 3.2" << std::endl;
    std::cout << sum(0, 1, 2, 3, 4, 10) << std::endl;          
    std::cout << sum(0.5, 0.2, 0.1, 0.1, 0.1) << std::endl;         
}

