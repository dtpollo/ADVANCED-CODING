#ifndef SOCCERPLAYER_H
#define SOCCERPLAYER_H

#include <string>

class SoccerPlayer {
public:
    // Construftors
    SoccerPlayer();  // Parameterless constructor
    SoccerPlayer(const std::string& name, int age, const std::string& team);

    // Public methods
    void printInfo() const;
    void changeTeam(const std::string& newTeam);

    std::string getName() const;
    int getAge() const;
    std::string getTeam() const;

    void setName(const std::string& name);
    void setAge(int age);
    void setTeam(const std::string& team);

private:
    std::string name_;
    int age_;
    std::string team_;
    void logChange(const std::string& changeType);
};

#endif
