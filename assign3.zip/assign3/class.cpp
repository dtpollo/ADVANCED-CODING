#include "class.h"
#include <iostream>

//Constructor
SoccerPlayer::SoccerPlayer() 
    : name_("Unknown"), age_(0), team_("Free Agent") {}

SoccerPlayer::SoccerPlayer(const std::string& name, int age, const std::string& team) 
    : name_(name), age_(age), team_(team) {}

// Methods
void SoccerPlayer::printInfo() const {
    std::cout << "Player Name: " << name_ << "\n";
    std::cout << "Age: " << age_ << "\n";
    std::cout << "Team: " << team_ << "\n";
}

void SoccerPlayer::changeTeam(const std::string& newTeam) {
    logChange("Team change");
    team_ = newTeam;
}

std::string SoccerPlayer::getName() const { return name_; }
int SoccerPlayer::getAge() const { return age_; }
std::string SoccerPlayer::getTeam() const { return team_; }

void SoccerPlayer::setName(const std::string& name) {
    logChange("Name change");
    name_ = name;
}

void SoccerPlayer::setAge(int age) {
    logChange("Age change");
    age_ = age;
}

void SoccerPlayer::setTeam(const std::string& team) {
    logChange("Team change");
    team_ = team;
}

// Private
void SoccerPlayer::logChange(const std::string& changeType) {
    std::cerr << changeType << " for player: " << name_ << "\n";
}
