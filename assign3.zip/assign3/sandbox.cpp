#include "class.h" 
#include <iostream>

void sandbox() {
    SoccerPlayer player1("Enner Valencia", 36, "Manchester City");
    player1.printInfo();

    player1.changeTeam("Barcelona Sporting Club");
    std::cout << "\nAfter changing team:\n";
    player1.printInfo();
}