//Daniel Troya
#include <iostream>
#include <vector>

int main() {
    std::vector<int> v1 = {1, 2, 3, 4};
    std::vector<int> v2 = v1;        // Copy
    std::vector<int> v3 = std::move(v1); // Move

    std::cout << "v1 size: " << v1.size() << std::endl;
    std::cout << "v2 size: " << v2.size() << std::endl;
    std::cout << "v3 size: " << v3.size() << std::endl;

    return 0;
}

/*
---------   QUESTIONS  ---------

• What is the output of this program?
The output is:
    v1 size: 0
    v2 size: 4
    v3 size: 4

• Why does v1.size() return 0 after the move?
When we transfer the data from v1 to v3 (line 11), 
v1 becomes empty and all it's data is now owned by v3.

• What does std::move do?
It enables moving resources from one object to another without 
copying. It marks the source object (v1) as movable, allowing 
it's data to be transferred efficiently to the destination (v3).

• Why is v1 still in a valid but unspecified state?
In C++, move from objects must remain valid but their contents are unspecified.
*/
