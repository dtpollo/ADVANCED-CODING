//Daniel Troya
#include <iostream>
#include <algorithm>


//Part 2.1
class Buffer {
private:
    int* data;
    size_t size;

public:
    Buffer(size_t s) : size(s), data(new int[s]) { //Constructor
        std::cout << "Constructor called\n";
    }

    ~Buffer() { // Destructor
        delete[] data;
        std::cout << "Destructor called\n";
    }


//Part 2.2
    Buffer(const Buffer& other) : size(other.size), data(new int[other.size]) {
        std::copy(other.data, other.data + other.size, data);
        std::cout << "Copy constructor called\n";
    }

    Buffer& operator=(const Buffer& other) {
        if (this != &other) {  
            delete[] data;    
            size = other.size;
            data = new int[size];
            std::copy(other.data, other.data + size, data);
            std::cout << "Copy assignment called\n";
        }
        return *this;
    }

//Part 2.3
    Buffer(Buffer&& other) noexcept 
        : data(other.data), size(other.size) {
        other.data = nullptr;
        other.size = 0;
        std::cout << "Move constructor called\n";
    }

//Part 2.3
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) { 
            delete[] data;
            data = other.data;
            size = other.size;
            other.data = nullptr;
            other.size = 0;
            std::cout << "Move assignment called\n";
        }
        return *this;
    }
};

//Part 3

int main() {
    Buffer buff1(7);              // Constructor
    Buffer buff2 = buff1;            // call copy constructor
    Buffer buff3 = std::move(buff1); // call move constructor
    
    Buffer buff4(2);
    buff4 = buff2;              // Should call copy assignment
    buff4 = std::move(buff2);  // Should call move assignment
    return 0;
}

/*
---------   QUESTIONS  ---------

• What constructors and assignments are called and when?
Constructor:
    - buff1(7) and buff4(2) (initialization)
    - Buffer buff2 = buff1 (copy)
    - Buffer buff3 = std::move(buff1) (move)
Assignment:
    - buff4 = buff2 (copy)
    - buff4 = std::move(buff2) (move)

• What happens to the source object after a move? 
When we move, the source data becomes 'nullptr' and its size becomes '0'

• What would happen if you didn't define the move constructor/assignment?
If we didn't define move operations, the compiler wouldn't generate 
them and would use copy operations instead.

*/