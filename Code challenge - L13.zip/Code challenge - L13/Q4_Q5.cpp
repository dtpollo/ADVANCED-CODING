//Daniel Troya
#include <iostream>
#include <chrono>
#include <vector> 


int main() {
    const size_t size = 10000000;
    std::vector<int> source(size, 42);
    
    auto start = std::chrono::high_resolution_clock::now();
    {
        std::vector<int> copy = source; //Copy
    }

    // Operation
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "Copy Duration: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    
    // Move
    source = std::vector<int>(size, 42);
    
    start = std::chrono::high_resolution_clock::now();
    {
        std::vector<int> moved = std::move(source);
    }
    end = std::chrono::high_resolution_clock::now();
    std::cout << "Move Duration: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";

    return 0;
}

/*
---------   QUESTIONS  ---------

• What did you learn about move semantics?
I learned that we can transfer data from one object to another,
and that we should consider the timing when we do this, because
it should consume less computational power.

• In what kinds of projects do you think this would matter?
This would be useful in game development, because
sometimes we initialize a class with large data values and when we
instantiate this, we need to transfer the data to another object
for specific operations.

• What are some risks of using std::move incorrectly?
The main risk is that we can lose the data from
the original object, because it will become 'nullptr', and
we can't recover this data.
*/